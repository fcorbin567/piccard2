.. _contents:

========================
piccard
========================
A graph-based approach to census data analysis. Developed by Abdulmohseen AlAli, Elise Corbin, and Maliha Lodi.

.. toctree::
   :maxdepth: 2
   :caption: Table of Contents

   introduction
   installation
   usage
   faq

Sections
========

Introduction
------------
.. include:: introduction.rst

Installation
------------
.. include:: installation.rst

Usage
-----
.. include:: usage.rst